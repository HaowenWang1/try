var global = this;

var console = {};
console.debug = print;
console.warn = print;
console.log = print;